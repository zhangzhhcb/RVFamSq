"%contain%" <- function(values,x) {
  tx <- table(x)
  tv <- table(values)
  z <- tv[names(tx)] - tx
  all(z >= 0 & !is.na(z))
}

#define negative likelihood function
nlf <- function(paras) {
  miu<-paras["miu"]
  sitag<-paras["sitag"]
  sitae<-paras["sitae"]

  betax<-paras[which(names(paras)!="miu"&names(paras)!="sitag"&names(paras)!="sitae")]

  sum_likelihood=0
  for (n in unique(simdata$famid)) {
    sid=which(simdata$famids==n)
    sid_count=length(sid)

    if(!is.null(ncol(simdata$covar))) {
      EYi=miu+rowSums(t(apply(simdata$covar[sid,],1,function(x) x*betax)))
    } else {
      EYi=miu+betax*simdata$covar[sid]
    }
    yi=simdata$pheno[sid]

    fid<-simdata$id[sid]
    kindex<-match(fid,rownames(kin))

    fani<-as.matrix(2*kin[kindex,kindex]*sitag^2)
    diag(fani)<-sitag^2 + sitae^2

    #negative log likelihood
    if (is.finite(log(det(fani)))) {
      sum_likelihood=sum_likelihood+dmvnorm(yi, EYi,fani,log=TRUE)
    }
  }
  return(-2*sum_likelihood)
}

#maximum likelihood function to get parameters
nlf_fit<-function(start) {
  parnames(nlf)<-c("miu",betax_names,"sitag","sitae")
  m1 <- mle2(nlf,start=start, data=simdata, method = "Nelder-Mead", skip.hessian = FALSE, control=list(trace=FALSE, maxit=1000))
  m2 <- mle2(nlf,start=coef(m1), control=list(trace=FALSE, maxit=1000, parscale=coef(m1)), data=simdata)
  return(m2)
}

#main function of the score model
Tscore<-function(ped,maf,paras,covar_update_col,trait_update_col,geno_update_col) {
  miu<-paras$miu
  sitag<-paras$sitag
  sitae<-paras$sitae
  betax<-unlist(paras[which(names(paras)!="miu"&names(paras)!="sitag"&names(paras)!="sitae")])

  if(!is.null(ncol(ped[,covar_update_col]))) {
    EYi=miu+rowSums(t(apply(ped[,covar_update_col],1,function(x) x*betax)))
  } else {
    EYi=miu+betax*ped[,covar_update_col]
  }

  yi<-ped[,trait_update_col]
  kindex<- match(ped[,2],rownames(kin))

  fanij<-as.matrix(2*kin[kindex,kindex]*sitag^2)
  diag(fanij)<-sitag^2 + sitae^2
  fanij_inv<-solve(fanij)

  g<-rowSums(ped[,geno_update_col]) - sum(2*maf)

  upperdot = t(g) %*% fanij_inv %*% (yi - EYi)
  lowerdot = t(g) %*% fanij_inv %*% g

  return(c(upperdot,lowerdot))
}

RV_FamSq <- function(genofile, phenofile, maffile, parafile,covar_col, trait_col, out,kin, start_par=NULL) {
  library(bbmle)
  library(mvtnorm)
  library(rlist)

  if(!file.exists(genofile)) stop("Genotype data does not exist.")
  if(!file.exists(maffile)) stop("MAF data does not exist.")
  if(!file.exists(phenofile)) stop("Phenotype data does not exist.")


  ped_pheno<-as.matrix(read.table(phenofile))
  ped_geno<-as.matrix(read.table(genofile))
  maf_data<-as.matrix(read.table(maffile))

  if (ped_pheno[,2] %contain% ped_geno[,2]) {

    miss_index<-which(is.na(ped_pheno[,covar_col]) | is.na(ped_pheno[,trait_col]))

    if(length(miss_index)>0) {
      print("Delete samples without the data of phenotype and covariant")
      ped_pheno<-ped_pheno[-miss_index,]
    }

    ped_pheno<-ped_pheno[,c(1:4,covar_col,trait_col)]
    geno_index<-match(ped_pheno[,2],ped_geno[,2])
    ped_data<-cbind(ped_pheno,ped_geno[geno_index,3:ncol(ped_geno)])

  } else {
    stop("Some samples in phenotype file miss the genotype data")
  }

  covar_update_col<-c(5:(4+length(covar_col)))
  trait_update_col<-c(5+length(covar_col))
  geno_update_col<-c((6+length(covar_col)):ncol(ped_data))

  genos<-ped_data[,geno_update_col]

  if(missing(kin)) {
    stop("Kinship matrix is missing.")
  } else {
    if (rownames(kin) %contain% ped_data[,2]) {
      assign("kin", kin, envir=.GlobalEnv)
    } else {
      stop("Some samples in pedfile are not included in Kinship matrix")
    }
  }

  if (ncol(genos)!=nrow(maf_data)) stop("Dimension of genotype and number of varints in MAF file does not match")

  if(!file.exists(parafile)) {
    par_num<-3+length(covar_col)
    if(is.null(start_par)) {
      print("Starting values of parameters are not defined, generating random initial values now...")
      start_par<-runif(par_num,-1,1)
    } else {
      if (length(start_par)<par_num) {
        print("Defined less parameters than required by the model, generating random initial values now...")
        start_par<-runif(par_num,-1,1)
      }
    }

    if (length(covar_col)>1) {
      assign("betax_names",paste0("betax",1:length(covar_col)), envir=.GlobalEnv)
    } else {
      assign("betax_names","betax", envir=.GlobalEnv)
    }

    paras <- start_par
    names(paras)<-c("miu",betax_names,"sitag","sitae")
    assign("simdata", list(id=ped_data[,2],pheno=ped_data[,trait_update_col],covar=ped_data[,covar_update_col],famids=ped_data[,1],genos=genos, maf=maf_data[,4]), envir=.GlobalEnv)
    print(paste("Estimating the values of parameters",paste(names(paras),collapse = ","),sep = " "))
    nullmod<-nlf_fit(paras)
    paras<-as.list(coef(nullmod))
    list.save(paras, parafile)
    RV_FamSq(pedfile, phenofile, maffile, parafile,covar_col, trait_col, out,kin)
  } else {
    print("Reading parameters from parafile... ")
    paras<-list.load(parafile)
    print(unlist(paras))

    peds_grp_by_fam<-split(seq_len(nrow(ped_data)),ped_data[,1])
    scores<-unlist(lapply(peds_grp_by_fam, function(x) Tscore(ped_data[unlist(x),],as.numeric(maf_data[,4]),paras,covar_update_col,trait_update_col,geno_update_col)))
    upper<-sum(scores[seq(1,length(scores),2)])
    lower<-sum(scores[seq(2,length(scores),2)])
    score<-upper^2/lower
    p=pchisq(score,df=1)

    gene_name=as.character(maf_data[1,1])
    out<-paste(c(out,"/", gene_name,".out"),collapse ="")
    pout<-data.frame(gene=gene_name, score=score, p=1-p, sample_size=nrow(ped_data), family_size=length(unique(ped_data[,1])))
    write.table(pout,out, row.names = FALSE, col.names = TRUE, quote=FALSE,sep="\t")
    print(pout)
  }
  return()
}
